# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.

"""Resolving Internet Names"""

from twisted.names._version import version
__version__ = version.short()
